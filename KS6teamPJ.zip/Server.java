

import javax.swing.*;
import java.awt.event.ActionListener;

class Server {
  Object o;
  String ip,port,id;

  LoginUi ui;
  Server(LoginUi ui, JFrame frame){
    this.ui = ui;
  }

}
