/*
package KS6teamPJ;

public class Liar extends ClientUi{


      Liar(LoginUi ui) {
            super(ui);
      }

      void guess(){

      }
}
*/
